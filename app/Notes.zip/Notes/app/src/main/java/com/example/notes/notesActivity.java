package com.example.notes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class notesActivity extends AppCompatActivity {
    FloatingActionButton mcreatenotefab;

    private FirebaseAuth firebaseauth;

    RecyclerView mrecyclerview;
    StaggeredGridLayoutManager mstaggerdgridlayoutmanager;

    FirebaseUser firebaseuser;
    FirebaseFirestore firebasefirestore;
    FirestoreRecyclerAdapter<firebasemodel,NoteViewHolder> noteadpter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);

        mcreatenotefab = findViewById(R.id.createnotefab);


        firebaseuser = FirebaseAuth.getInstance().getCurrentUser();
        firebasefirestore = FirebaseFirestore.getInstance();

        getSupportActionBar().setTitle("Your Notes");

        mcreatenotefab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(notesActivity.this,createnote.class));
            }
        });

        Query query = firebasefirestore.collection("notes").document(firebaseuser.getUid()).collection("myNotes").orderBy("title",Query.Direction.ASCENDING);

        FirestoreRecyclerOptions<firebasemodel> allusernotes = new FirestoreRecyclerOptions.Builder<firebasemodel>().setQuery(query,firebasemodel.class).build();

        noteadpter = new FirestoreRecyclerAdapter<firebasemodel,NoteViewHolder>(allusernotes){
            @Override
            protected void onBindViewHolder(@NonNull NoteViewHolder noteviewholder, int i, @NonNull firebasemodel  firebasemodel) {

                noteviewholder.notetitles.setText(firebasemodel.getTitle());
                noteviewholder.notecontents.setText(firebasemodel.getContent());


            }
            @NonNull
            @Override
            public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.noteslayout,parent,false);
                return  new NoteViewHolder(view);
            }
        };

        mrecyclerview = findViewById(R.id.recyclerview);
        mrecyclerview.setHasFixedSize(true);
        mstaggerdgridlayoutmanager = new StaggeredGridLayoutManager(2,StaggeredGridLayoutManager.VERTICAL);
        mrecyclerview.setLayoutManager(mstaggerdgridlayoutmanager);
        mrecyclerview.setAdapter(noteadpter);

    }


    public class NoteViewHolder extends RecyclerView.ViewHolder{
        private TextView notetitles;
        private TextView notecontents;
        LinearLayout mnote;

        public  NoteViewHolder(@NonNull View itemView){
            super(itemView);
            notetitles = itemView.findViewById(R.id.notetitle);
            notecontents = itemView.findViewById(R.id.notecontent);
            mnote = itemView.findViewById(R.id.note);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.logout:
                firebaseauth.signOut();
                finish();
                startActivity(new Intent(notesActivity.this,MainActivity.class));
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        super.onStart();
        noteadpter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(noteadpter!=null){
            noteadpter.stoptListening();
        }
    }
}